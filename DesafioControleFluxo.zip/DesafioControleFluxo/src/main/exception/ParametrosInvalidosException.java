package main.exception;

public class ParametrosInvalidosException extends Exception {

	private static final long serialVersionUID = 1L;

}
